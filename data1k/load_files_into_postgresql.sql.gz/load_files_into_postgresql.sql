--------------------------------------------------------------------
-- This SQL script loads a 1000 person sample of simulated CMS SynPUF patient data from csv files into a subset of the OMOP Common Data Model Version 5 (CDMV5) tables.
--
-- Change the below file paths to reference the folder where you unzipped the csv data files
--
-- LTS Computing LLC
-- http://www.ltscomputingllc.com
--------------------------------------------------------------------
--
COPY CARE_SITE FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_CARE_SITE.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY CONDITION_OCCURRENCE FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_CONDITION_OCCURRENCE.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY DEATH FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_DEATH.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY DRUG_EXPOSURE FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_DRUG_EXPOSURE.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY DEVICE_EXPOSURE FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_DEVICE_EXPOSURE.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY LOCATION FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_LOCATION.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY MEASUREMENT FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_MEASUREMENT.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY OBSERVATION FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_OBSERVATION.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY OBSERVATION_PERIOD FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_OBSERVATION_PERIOD.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY PERSON FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_PERSON.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY PROCEDURE_OCCURRENCE FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_PROCEDURE_OCCURRENCE.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY PROVIDER FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_PROVIDER.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY VISIT_OCCURRENCE FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_VISIT_OCCURRENCE.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY DRUG_ERA FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_DRUG_ERA.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
COPY CONDITION_ERA FROM '/mnt/storage/RWEdatasets/CMS-DE-SynPUF/output/CDM_CONDITION_ERA.csv' WITH DELIMITER E',' CSV HEADER QUOTE E'\b';
